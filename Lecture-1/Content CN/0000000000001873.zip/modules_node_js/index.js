const operations =  require('./operations');

console.log(operations.add(2, 3));
console.log(operations.multiply(2, 3));