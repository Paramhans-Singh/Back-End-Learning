
module.exports.chatSockets = function(socketServer){

}