const express = require('express');

const router = express.Router();

console.log('router loaded');


module.exports = router;