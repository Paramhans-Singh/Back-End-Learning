import React from 'react';


function Post(props) {

    let postStyle = {
        color: 'grey'
    }

  return (
    <li className="PostItem" style={postStyle}>

    </li>
  );
}

export default Post;