import React from 'react';


class PostsList extends React.Component{


  render(){
    return (
        <div>
            <h1>Codeial Posts</h1>
            <ul>

            </ul>
        </div>
      );
  }
}

export default PostsList;